export const base_url = "https://ratio-nais-desc-22-23.onrender.com";
