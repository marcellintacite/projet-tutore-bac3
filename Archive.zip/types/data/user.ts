export type userType = {
  userId: string;
  username: string;
  email: string;
  userRole: string;
  token: string;
};
