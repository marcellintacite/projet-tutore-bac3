export type InputsDeces = {
  medecin_traitant: string;
  nom_defunt: string;
  prenom_defunt: string;
  postnom_defunt: string;
  sexe_defunt: string;
  cause_desc: string;
  id?: number;
  date_desc?: string;
  date_naissance_defunt?: string;
};
